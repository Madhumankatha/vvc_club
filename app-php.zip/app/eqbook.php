<?php

$arr = array(
    'id'=>1,
    'title' => 'E Question bank',
    'pdf' =>'http://bcassist.in/app/Study/uploads/DEADLOCKS.pdf',
    'date'=>'Oct 27,2019',
    'category'=>'Documents',
    'author'=>'madhu'
    );
    
    echo json_encode(array($arr,$arr));

?>