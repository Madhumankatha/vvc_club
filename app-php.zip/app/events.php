<?php

$arr = array(
    'id'=>1,
    'title' => 'Java Question papaer',
    'pdf' =>'facebook.com',
    'img' => 'https://05e6c80102b0f1022a3a-fc37cf63fac2740800d04da8b0039300.ssl.cf3.rackcdn.com/wp-content/uploads/2017/12/Java-Events-2019.png',
    'date'=>'Oct 27,2019',
    'category'=>'Question papaer',
    'desc'=>'Hello World!',
    'author'=>'madhu'
    );
    
    echo json_encode(array($arr,$arr));

?>